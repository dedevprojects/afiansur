import React from 'react';
import { ArrowUpRight } from 'lucide-react';
import { Brand } from '../data/afiansurData';

interface TechnologyShowcaseProps {
  onSelectBrand: (brand: Brand) => void;
  brands: Brand[];
}

export const TechnologyShowcase: React.FC<TechnologyShowcaseProps> = ({ onSelectBrand, brands }) => {
  const agenciaGol = brands.find((b) => b.id === 'agencia-gol') || brands[0];
  const agroconexiones = brands.find((b) => b.id === 'agroconexiones');
  const reservaclick = brands.find((b) => b.id === 'reservaclick');
  const inmobiliosis = brands.find((b) => b.id === 'inmobiliosis');

  const products = [agroconexiones, reservaclick, inmobiliosis].filter(Boolean) as Brand[];

  return (
    <section className="w-full px-6 md:px-16 py-20 md:py-24 bg-[#f4f3f1] border-b border-[#d3cfc8]/40" id="tecnologia">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="max-w-3xl mb-14 md:mb-16">
          <span className="text-[11px] uppercase tracking-[0.2em] font-semibold text-[#5f5d59] block mb-2">
            DESARROLLO DE NEGOCIOS DIGITALES
          </span>
          <h2 className="font-serif text-[38px] md:text-[52px] text-[#191b1b] tracking-tight leading-tight mb-4">
            De la ingeniería al producto.
          </h2>
          <p className="text-[16px] md:text-[17px] text-[#5f5d59] leading-relaxed">
            A través de <strong className="text-[#191b1b] font-semibold">Agencia Gol</strong> desarrollamos tecnología, plataformas y productos digitales propios. Agroconexiones, ReservaClick e Inmobiliosis responden a necesidades concretas de sus respectivos mercados. Cada producto tiene una propuesta específica y una identidad propia dentro del grupo.
          </p>
        </div>

        {/* Studio Core & Products Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 md:gap-10 items-stretch">
          {/* Studio Core: Agencia Gol */}
          <div className="lg:col-span-5 bg-[#f9f9f8] border border-[#d3cfc8]/70 p-6 md:p-8 flex flex-col justify-between shadow-xs hover:shadow-md transition-shadow">
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-[#d3cfc8]/40 text-[#5f5d59]">
                <span className="text-[11px] uppercase tracking-[0.18em] font-semibold">ESTUDIO CENTRAL</span>
                <span className="text-[11px] uppercase tracking-wider text-[#7b766f]">DESARROLLO E INGENIERÍA</span>
              </div>

              <div className="my-6">
                <button
                  onClick={() => onSelectBrand(agenciaGol)}
                  className="text-left font-serif text-[30px] md:text-[34px] text-[#191b1b] mb-1.5 hover:underline decoration-1 underline-offset-4 cursor-pointer block leading-tight"
                >
                  Agencia Gol
                </button>
                <p className="text-[11px] uppercase tracking-widest text-[#5f5d59] font-medium">
                  Centro de Diseño, Arquitectura de Software y Soluciones a Medida
                </p>
              </div>

              <p className="text-[15px] text-[#5f5d59] leading-relaxed mb-6">
                Opera como el motor tecnológico transversal de Grupo Afiansur. Desarrolla la infraestructura, los sistemas distribuidos y la experiencia interactiva que nutren tanto a clientes externos como al ecosistema interno del grupo.
              </p>

              <div className="aspect-[16/9] w-full overflow-hidden bg-[#edebe7] mb-4 border border-[#d3cfc8]/50 group relative">
                <img
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuCblhGt609dnZksgT3QQqxEdc1V09G4iRdJWkH-f9y0CjTI0P2XTgGu9Q-R1R2sb3B8JwP79by3DbAW7YM0JXQlLldDDtwzPx6pxQlKLtReQgcY9qbP5-HVaBJ-BV5bwWDY81Hhoe7Zs18xOYilkbAKpzF2NiWcIAyvOyBl3XgLjyXfEFcO0tf1YgbCXVlh2pShOoCEUeOSIUimrGZdl23askrGc30zbofySeY3fSkUVw-nnmJbNVwxmQ"
                  alt="Arquitectura de desarrollo e ingeniería en Agencia Gol"
                  className="w-full h-full object-cover filter grayscale contrast-105 group-hover:scale-105 transition-transform duration-700"
                />
              </div>
            </div>

            <div className="pt-5 border-t border-[#d3cfc8]/40 flex items-center justify-between">
              <a
                href={agenciaGol.url}
                target="_blank"
                rel="noopener noreferrer"
                className="group inline-flex items-center gap-1.5 text-[11px] uppercase tracking-[0.18em] font-semibold text-[#191b1b] hover:text-[#5f5d59] transition-colors"
              >
                <span>Visitar agenciagol.com.ar</span>
                <ArrowUpRight className="w-3.5 h-3.5 transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </a>

              <button
                onClick={() => onSelectBrand(agenciaGol)}
                className="text-[11px] uppercase tracking-[0.14em] text-[#7b766f] hover:text-[#191b1b] transition-colors font-medium cursor-pointer"
              >
                Ver ficha técnica
              </button>
            </div>
          </div>

          {/* 3 Digital Products */}
          <div className="lg:col-span-7 flex flex-col justify-between gap-6">
            {products.map((product) => {
              const domain = product.url.replace(/^https?:\/\//, '').replace(/\/$/, '');
              const subMeta = product.id === 'agroconexiones'
                ? { tag: 'SECTOR AGROPECUARIO', left: 'TECNOLOGÍA AGROINDUSTRIAL', right: 'SOLUCIÓN EMPRESARIAL' }
                : product.id === 'reservaclick'
                ? { tag: 'GESTIÓN DE TURNOS Y SERVICIOS', left: 'AUTOMATIZACIÓN DIGITAL', right: 'GESTIÓN OPERATIVA' }
                : { tag: 'SECTOR INMOBILIARIO', left: 'GESTIÓN DE PROPIEDADES', right: 'PLATAFORMA MULTICANAL' };

              return (
                <div
                  key={product.id}
                  className="group bg-[#f9f9f8] border border-[#d3cfc8]/70 p-6 md:p-7 flex-1 shadow-xs hover:shadow-md hover:border-[#191b1b]/40 transition-all flex flex-col justify-between"
                >
                  <div>
                    <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2 pb-3 border-b border-[#d3cfc8]/30 mb-3">
                      <div>
                        <span className="text-[10px] tracking-widest uppercase text-[#5f5d59] font-medium block">
                          {subMeta.tag}
                        </span>
                        <button
                          onClick={() => onSelectBrand(product)}
                          className="font-serif text-[24px] md:text-[26px] text-[#191b1b] text-left hover:underline decoration-1 underline-offset-4 cursor-pointer"
                        >
                          {product.name}
                        </button>
                      </div>

                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => onSelectBrand(product)}
                          className="text-[11px] uppercase tracking-wider text-[#7b766f] hover:text-[#191b1b] font-medium"
                        >
                          Dossier
                        </button>
                        <a
                          href={product.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-[11px] uppercase tracking-widest font-semibold text-[#191b1b] hover:text-[#5f5d59] transition-colors"
                        >
                          <span>{domain}</span>
                          <ArrowUpRight className="w-3.5 h-3.5 transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                        </a>
                      </div>
                    </div>

                    <p className="text-[15px] text-[#5f5d59] leading-relaxed">
                      {product.fullDescription}
                    </p>
                  </div>

                  <div className="mt-5 pt-3 border-t border-[#d3cfc8]/20 flex items-center justify-between text-[11px] uppercase tracking-wider text-[#7b766f]">
                    <span>{subMeta.left}</span>
                    <span>{subMeta.right}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
