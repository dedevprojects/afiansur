import React from 'react';
import { ArrowRight } from 'lucide-react';

interface InstitutionalClosingProps {
  onOpenContact: () => void;
}

export const InstitutionalClosing: React.FC<InstitutionalClosingProps> = ({ onOpenContact }) => {
  return (
    <section className="relative w-full px-6 md:px-16 py-20 md:py-28 bg-[#f4f3f1] overflow-hidden border-b border-[#d3cfc8]/40" id="contacto-cierre">
      <div className="relative z-10 max-w-3xl mx-auto text-center flex flex-col items-center">
        {/* Monogram Seal */}
        <a href="#" className="inline-block mb-6 group focus:outline-hidden" aria-label="Grupo Afiansur">
          <img
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuDuPMaGs09PF_dXc3hJ7pBBy53NCzIEHGxIykOFDrbGdL5AOZPU_iEHjFxHTQjAEvyAcopOZ_-w3gLDgQeYB6Y73K0xfXSO_CwV39iuID9JiZFTrpDOkd94AjH_ZHiZER2P2I-NKHiFEIKU8ZL4Me_lEzMd8FiHty942_DQuJ4jHh_BlJBVyrFb4U0dW3LG_zHJOZnwMYwtQ_ERbvgv5vVqgPfbzhUNHFURN4Nu_MZeQiivOLhquFCy7VEML89HSifnp-A"
            alt="Grupo Afiansur"
            className="h-12 md:h-14 w-auto object-contain mix-blend-multiply opacity-90 transition-opacity duration-200 group-hover:opacity-100"
          />
        </a>

        {/* Micro tag */}
        <span className="text-[11px] uppercase tracking-[0.24em] font-semibold text-[#5f5d59] mb-3">
          RELACIONES INSTITUCIONALES
        </span>

        {/* Title */}
        <h2 className="font-serif text-[40px] md:text-[54px] text-[#191b1b] tracking-tight leading-tight mb-5">
          Nuevas ideas. <br className="hidden sm:inline" />
          <span className="italic font-light">Nuevos negocios.</span>
        </h2>

        {/* Text */}
        <p className="text-[16px] md:text-[17px] text-[#5f5d59] leading-relaxed max-w-xl mb-8">
          Grupo Afiansur reúne capacidades y experiencias diversas para desarrollar proyectos, establecer alianzas y explorar nuevas oportunidades de negocio con solidez institucional.
        </p>

        {/* CTA */}
        <div className="flex flex-col sm:flex-row items-center gap-4">
          <button
            onClick={onOpenContact}
            className="group inline-flex items-center gap-2 px-8 py-3.5 bg-[#121313] text-white text-[11px] font-semibold uppercase tracking-[0.2em] transition-all duration-300 hover:bg-black hover:shadow-lg hover:-translate-y-0.5 cursor-pointer"
          >
            <span>Contactar al grupo</span>
            <ArrowRight className="w-3.5 h-3.5 transition-transform duration-200 group-hover:translate-x-1" />
          </button>
        </div>

        {/* Corporate Legal & Geographics */}
        <div className="mt-16 pt-6 border-t border-[#d3cfc8]/40 w-full flex flex-col sm:flex-row items-center justify-between text-[#7b766f] text-[11px] uppercase tracking-widest gap-2">
          <span>GRUPO AFIANSUR S.A.</span>
          <span>BUENOS AIRES • ASUNCIÓN • MADRID</span>
        </div>
      </div>
    </section>
  );
};
