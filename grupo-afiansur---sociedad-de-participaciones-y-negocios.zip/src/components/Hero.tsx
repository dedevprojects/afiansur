import React, { useState } from 'react';
import { ArrowRight, Building2, ExternalLink } from 'lucide-react';

interface HeroProps {
  onOpenArchitecture: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenArchitecture }) => {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    setMousePos({ x: x * 8, y: y * 8 });
  };

  const handleMouseLeave = () => {
    setMousePos({ x: 0, y: 0 });
  };

  return (
    <section className="relative w-full px-6 md:px-16 pt-8 md:pt-14 pb-20 md:pb-24 border-b border-[#d3cfc8]/40 bg-[#f9f9f8] overflow-hidden" id="hero">
      <div className="max-w-7xl mx-auto">
        {/* Top Institutional Metadata Bar */}
        <div className="animate-fade-in-up flex items-center justify-between pb-4 border-b border-[#d3cfc8]/40 text-[#5f5d59] text-[11px]">
          <div className="flex items-center gap-4">
            <span className="inline-flex items-center gap-1.5 font-semibold uppercase tracking-[0.2em] text-[#191b1b]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#121313] inline-block"></span>
              ESTRUCTURA Y GOBIERNO CORPORATIVO
            </span>
            <span className="text-[#d3cfc8] hidden sm:inline">|</span>
            <span className="text-[11px] uppercase tracking-widest hidden sm:inline text-[#5f5d59] font-medium">
              GRUPO AFIANSUR
            </span>
          </div>
          <div className="flex items-center gap-6 text-right">
            <span className="text-[11px] tracking-widest uppercase hidden md:inline text-[#7b766f]">
              EDICIÓN INSTITUCIONAL · 2025
            </span>
            <span className="text-[11px] tracking-widest uppercase text-[#5f5d59] font-medium">
              BUENOS AIRES · ASUNCIÓN · MADRID
            </span>
          </div>
        </div>

        {/* Main Asymmetric Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 md:gap-14 mt-8 md:mt-12 items-center">
          {/* Left Column: Typography & Corporate Mission */}
          <div className="lg:col-span-6 flex flex-col justify-between z-10">
            <div>
              {/* Micro tag */}
              <div className="inline-flex items-center gap-2 mb-3">
                <span className="text-[11px] uppercase tracking-[0.22em] text-[#5f5d59] font-semibold">
                  SOCIEDAD DE PARTICIPACIONES Y NEGOCIOS
                </span>
                <span className="w-8 h-px bg-[#d3cfc8]"></span>
              </div>

              {/* Main Headline */}
              <h1 className="font-serif text-[42px] sm:text-[54px] md:text-[66px] lg:text-[74px] text-[#191b1b] tracking-tight leading-[1.06] mb-6 font-normal">
                Negocios distintos. <br />
                <span className="italic font-light text-[#191b1b]/90">Una visión compartida.</span>
              </h1>
            </div>

            {/* Paragraph & Action Buttons */}
            <div className="pt-5 border-t border-[#d3cfc8]/40 space-y-5">
              <p className="text-[16px] md:text-[17px] text-[#44413c] leading-relaxed max-w-xl">
                Reunimos y desarrollamos negocios en tecnología, comunicación, talento, medios y educación. Cada uno con su propia identidad, capacidades y oportunidades de crecimiento.
              </p>

              <div className="pt-2 flex flex-wrap items-center gap-6">
                <a
                  href="#el-grupo"
                  className="group inline-flex items-center justify-center gap-2 px-7 py-3.5 bg-[#121313] text-white text-[11px] font-semibold uppercase tracking-[0.2em] transition-all duration-300 hover:bg-black hover:shadow-md hover:-translate-y-0.5"
                >
                  <span>Conocer el grupo</span>
                  <ArrowRight className="w-3.5 h-3.5 transition-transform duration-200 group-hover:translate-x-1" />
                </a>

                <a
                  href="#nuestros-negocios"
                  className="group relative inline-flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-[#191b1b] py-2 hover:text-black transition-colors"
                >
                  <span>Nuestros negocios</span>
                  <ArrowRight className="w-3.5 h-3.5 transition-transform duration-200 group-hover:translate-x-1" />
                  <span className="absolute bottom-0 left-0 w-full h-px bg-[#191b1b] transition-all duration-300 group-hover:w-0"></span>
                  <span className="absolute bottom-0 left-0 w-0 h-px bg-[#121313] transition-all duration-300 group-hover:w-full"></span>
                </a>
              </div>
            </div>

            {/* Corporate Values Bar */}
            <div className="mt-10 md:mt-14 pt-4 flex items-center justify-between text-[#7b766f] border-t border-[#d3cfc8]/30">
              <div className="flex items-center gap-3">
                <span className="text-[11px] uppercase tracking-[0.22em] text-[#5f5d59] font-medium">RIGOR</span>
                <span className="text-[#d3cfc8]">•</span>
                <span className="text-[11px] uppercase tracking-[0.22em] text-[#5f5d59] font-medium">DISCIPLINA</span>
                <span className="text-[#d3cfc8]">•</span>
                <span className="text-[11px] uppercase tracking-[0.22em] text-[#5f5d59] font-medium">GOBIERNO CORPORATIVO</span>
              </div>
              <div className="hidden sm:flex items-center gap-1.5 opacity-40 font-mono text-xs select-none">
                <span>+</span>
                <span>+</span>
                <span>+</span>
              </div>
            </div>
          </div>

          {/* Right Column: Architectural Composition */}
          <div className="lg:col-span-6 relative mt-6 lg:mt-0">
            <div
              onMouseMove={handleMouseMove}
              onMouseLeave={handleMouseLeave}
              onClick={onOpenArchitecture}
              className="relative group bg-[#f4f3f1] p-2 md:p-3 border border-[#d3cfc8]/60 transition-all duration-500 shadow-xs hover:shadow-md cursor-pointer"
              title="Haga clic para ver los espacios arquitectónicos de Grupo Afiansur"
            >
              {/* Architectural Image Container */}
              <div className="relative aspect-[16/11] md:aspect-[16/10] w-full overflow-hidden bg-[#edebe7]">
                <img
                  src="https://lh3.googleusercontent.com/aida/AEtjO1VdhwK2z2bxwe8HruMd0H08Hw-n_CBgfmTrMEEeGpNOz97CajbyuPNJZQ6H9ITCifR3J71ovT1OVtebyzcpNbZDc59kiaQYLFyesL7LHqU8DiBhFjpM679dLwy2L1arp7DWBH3LiTQJ-KhqOsCbNvxry4PFDa0lrMdg2J8BzGZCtZD1r9D7oW615f8Kd2g3qWUtpxYarRyn905k9WuEMXgi2Fn_ybMcAtPPT5eapQqCGfQOfV15XnpHAgqv"
                  alt="Oficinas centrales contemporáneas de Grupo Afiansur"
                  style={{
                    transform: `scale(1.03) translate(${mousePos.x}px, ${mousePos.y}px)`,
                    transition: 'transform 0.4s cubic-bezier(0.16, 1, 0.3, 1)',
                  }}
                  className="w-full h-full object-cover filter contrast-[1.03] brightness-[0.98]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/25 via-transparent to-transparent pointer-events-none"></div>

                {/* Floating Top Badge */}
                <div className="absolute top-4 left-4 z-10 subtle-glass px-3 py-1.5 border border-white/70 shadow-xs flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse"></span>
                  <span className="text-[10px] tracking-[0.16em] uppercase text-[#191b1b] font-semibold">
                    SEDE CORPORATIVA · ESPACIOS DE DIRECCIÓN
                  </span>
                </div>

                <div className="absolute top-4 right-4 z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 subtle-glass px-2.5 py-1 text-[10px] uppercase tracking-wider text-[#191b1b] flex items-center gap-1">
                  <span>Ver galería</span>
                  <ExternalLink className="w-3 h-3" />
                </div>
              </div>

              {/* Floating Metrics Overlay Card */}
              <div className="absolute -bottom-5 -left-4 md:-bottom-6 md:-left-6 z-20 subtle-glass border border-[#d3cfc8]/70 p-4 md:p-5 shadow-lg max-w-[280px] sm:max-w-[310px] backdrop-blur-md">
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#d3cfc8]/40">
                  <span className="text-[10px] uppercase tracking-[0.2em] text-[#5f5d59] font-medium">
                    ESTRUCTURA OPERATIVA
                  </span>
                  <span className="font-mono text-[11px] text-[#7b766f] font-semibold">05 / 12</span>
                </div>
                <p className="font-serif text-[19px] leading-tight text-[#191b1b]">
                  5 Áreas de actividad <br />
                  <span className="text-[#5f5d59] text-[14px] font-sans font-normal">
                    12 Marcas y plataformas consolidadas
                  </span>
                </p>
              </div>
            </div>

            {/* Caption & Coordinates */}
            <div className="mt-7 pt-1 flex items-center justify-between px-1 text-[#5f5d59]">
              <span className="text-[10px] uppercase tracking-[0.2em] text-[#5f5d59] flex items-center gap-1.5 font-medium">
                <Building2 className="w-3.5 h-3.5 text-[#7b766f]" />
                ESPACIOS DE GESTIÓN Y DIRECCIÓN ESTRATÉGICA
              </span>
              <button
                onClick={onOpenArchitecture}
                className="text-[10px] tracking-wider text-[#7b766f] uppercase font-mono hover:text-[#191b1b] transition-colors underline decoration-dotted underline-offset-2"
              >
                REF. ARQ-01 ↗
              </button>
            </div>
          </div>
        </div>

        {/* Decorative Grid Dots */}
        <div className="hidden lg:block absolute bottom-4 right-8 w-24 h-8 editorial-grid-dots opacity-30 pointer-events-none"></div>
      </div>
    </section>
  );
};
