import React, { useState, useEffect } from 'react';
import { ArrowUpRight, Menu, X, FileText } from 'lucide-react';

interface HeaderProps {
  onOpenContact: () => void;
  onOpenReport: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenContact, onOpenReport }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'El grupo', href: '#el-grupo' },
    { label: 'Unidades de negocio', href: '#unidades' },
    { label: 'Nuestros negocios', href: '#nuestros-negocios' },
  ];

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
          isScrolled
            ? 'subtle-glass border-b border-[#d3cfc8]/50 shadow-xs'
            : 'bg-[#f9f9f8]/90 border-b border-[#d3cfc8]/30'
        }`}
      >
        <div className="h-20 md:h-24 w-full px-6 md:px-16 flex items-center justify-between max-w-7xl mx-auto">
          {/* Official Logo */}
          <div className="flex items-center gap-6">
            <a
              href="#"
              className="flex items-center group py-2 focus:outline-hidden"
              aria-label="Grupo Afiansur - Inicio"
            >
              <img
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuBzaqOgQFU1JIESnzq1pYekjSeQmr2G_8FViaYtbM7syaEZxsY8DORcuGuQ9o-1rcQWd_blDPh9DNPR3dXIPaXMOHV-a8NDU3-549tf7qq8GBH_MRxKiQzNefR3KzGJ0JaEEGCFe_QeAqD5pRRbTcuM7pYcurjLMKn8nDCsxpcE6Vypf-kJOtJov1MRzGQpbklCOtaa82QjkHg2wF1MdJS-0rrMT2kES8laEK-WHebn8mN8IUkwflfzH4f7xzRU2w-Y_mc"
                alt="Grupo Afiansur"
                className="h-9 md:h-11 w-auto object-contain mix-blend-multiply transition-opacity duration-200 group-hover:opacity-80"
              />
            </a>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-10">
            {navItems.map((item) => (
              <a
                key={item.href}
                href={item.href}
                className="text-[11px] uppercase tracking-[0.18em] font-semibold text-[#5f5d59] hover:text-[#191b1b] transition-colors py-1 nav-link-indicator"
              >
                {item.label}
              </a>
            ))}
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-3">
            <button
              onClick={onOpenReport}
              className="hidden lg:inline-flex items-center gap-1.5 text-[11px] uppercase tracking-[0.16em] font-medium px-3.5 py-2 text-[#5f5d59] hover:text-[#191b1b] transition-colors"
              title="Ver Memoria Institucional 2025"
            >
              <FileText className="w-3.5 h-3.5 text-[#7b766f]" />
              <span>Memoria 2025</span>
            </button>

            <button
              onClick={onOpenContact}
              className="group inline-flex items-center gap-1.5 text-[11px] uppercase tracking-[0.2em] font-semibold px-5 md:px-6 py-2 md:py-2.5 border border-[#191b1b]/80 text-[#191b1b] hover:bg-[#121313] hover:text-white hover:border-[#121313] transition-all duration-300 rounded-full cursor-pointer"
            >
              <span>Contacto</span>
              <ArrowUpRight className="w-3.5 h-3.5 transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </button>

            {/* Mobile menu trigger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-[#191b1b] hover:text-black focus:outline-hidden"
              aria-label="Menú principal"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile dropdown */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-[#d3cfc8]/60 bg-[#f9f9f8] px-6 py-6 space-y-4">
            <nav className="flex flex-col space-y-4">
              {navItems.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="text-xs uppercase tracking-[0.18em] font-medium text-[#191b1b] py-1 border-b border-[#d3cfc8]/30 pb-2"
                >
                  {item.label}
                </a>
              ))}
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenReport();
                }}
                className="flex items-center gap-2 text-xs uppercase tracking-[0.18em] text-[#5f5d59] py-1 text-left"
              >
                <FileText className="w-4 h-4" />
                <span>Memoria Institucional 2025</span>
              </button>
            </nav>
          </div>
        )}
      </header>
    </>
  );
};
