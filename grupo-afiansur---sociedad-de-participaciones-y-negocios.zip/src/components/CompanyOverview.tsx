import React from 'react';
import { ShieldCheck, Layers, Globe } from 'lucide-react';

interface CompanyOverviewProps {
  onOpenReport: () => void;
}

export const CompanyOverview: React.FC<CompanyOverviewProps> = ({ onOpenReport }) => {
  return (
    <section className="w-full px-6 md:px-16 py-20 md:py-24 bg-[#f4f3f1] border-b border-[#d3cfc8]/40" id="el-grupo">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 md:gap-14 items-baseline">
          {/* Subtitle Column */}
          <div className="md:col-span-4 space-y-4">
            <div className="flex items-center gap-2">
              <span className="text-[11px] uppercase tracking-[0.2em] font-semibold text-[#5f5d59]">
                IDENTIDAD Y ESTRUCTURA
              </span>
            </div>
            <h2 className="font-serif text-[32px] md:text-[36px] text-[#191b1b] tracking-tight leading-tight max-w-sm">
              Distintas especialidades. Una estructura común.
            </h2>
            <div className="w-12 h-px bg-[#121313]/60"></div>
            <p className="text-[11px] uppercase tracking-[0.16em] text-[#5f5d59] font-medium pt-1">
              SINERGIA ESTRATÉGICA Y GOBIERNO AUTÓNOMO
            </p>

            {/* Quick Action */}
            <div className="pt-4 hidden md:block">
              <button
                onClick={onOpenReport}
                className="text-[11px] uppercase tracking-[0.18em] text-[#191b1b] hover:text-black font-semibold inline-flex items-center gap-2 border-b border-[#191b1b]/40 hover:border-[#191b1b] pb-1 transition-all"
              >
                <span>Consultar Memoria Institucional</span>
                <span className="text-[13px]">→</span>
              </button>
            </div>
          </div>

          {/* Narrative Column */}
          <div className="md:col-span-8 space-y-8">
            <div className="border-l border-[#d3cfc8]/80 pl-6 md:pl-10 space-y-4">
              <p className="font-sans text-[17px] md:text-[18px] text-[#191b1b] leading-relaxed">
                Grupo Afiansur reúne negocios con identidades y especialidades propias bajo una visión empresarial compartida. Nuestra estructura combina desarrollo tecnológico, producción creativa, gestión del talento, contenidos y formación.
              </p>
              <p className="font-sans text-[15px] md:text-[16px] text-[#5f5d59] leading-relaxed">
                Una diversidad de actividades que permite abordar distintos mercados y desarrollar nuevas iniciativas, conservando al mismo tiempo el estándar de precisión y solidez institucional que distingue a nuestras marcas.
              </p>
            </div>

            {/* Corporate Principles Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-4 border-t border-[#d3cfc8]/40">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2 text-[#191b1b]">
                  <Layers className="w-4 h-4 text-[#7b766f]" />
                  <span className="text-xs uppercase tracking-wider font-semibold">Autonomía Operativa</span>
                </div>
                <p className="text-xs text-[#5f5d59] leading-relaxed">
                  Cada subsidiaria gestiona su producto, equipo y relación con sus clientes con identidad propia.
                </p>
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center gap-2 text-[#191b1b]">
                  <ShieldCheck className="w-4 h-4 text-[#7b766f]" />
                  <span className="text-xs uppercase tracking-wider font-semibold">Gobernanza Unificada</span>
                </div>
                <p className="text-xs text-[#5f5d59] leading-relaxed">
                  Estándares transversales de auditoría legal, financiera y rigor metodológico institucional.
                </p>
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center gap-2 text-[#191b1b]">
                  <Globe className="w-4 h-4 text-[#7b766f]" />
                  <span className="text-xs uppercase tracking-wider font-semibold">Presencia Regional</span>
                </div>
                <p className="text-xs text-[#5f5d59] leading-relaxed">
                  Operaciones coordinadas desde Argentina, Paraguay y España para clientes globales.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
