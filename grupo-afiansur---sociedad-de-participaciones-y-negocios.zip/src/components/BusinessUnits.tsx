import React from 'react';
import { BUSINESS_UNITS } from '../data/afiansurData';

interface BusinessUnitsProps {
  onSelectBrandName: (brandName: string) => void;
}

export const BusinessUnits: React.FC<BusinessUnitsProps> = ({ onSelectBrandName }) => {
  return (
    <section className="w-full px-6 md:px-16 py-20 md:py-24 bg-[#f9f9f8] border-b border-[#d3cfc8]/40" id="unidades">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between pb-12 border-b border-[#d3cfc8]/40 gap-6">
          <div>
            <span className="text-[11px] uppercase tracking-[0.2em] font-semibold text-[#5f5d59] block mb-2">
              ÁREAS DE ACTIVIDAD
            </span>
            <h2 className="font-serif text-[38px] md:text-[52px] text-[#191b1b] tracking-tight leading-tight">
              Cinco áreas de especialización.
            </h2>
          </div>
          <p className="text-[15px] md:text-[16px] text-[#5f5d59] max-w-md leading-relaxed">
            Cada unidad responde a una actividad específica y reúne marcas que comparten capacidades, conocimientos y mercados.
          </p>
        </div>

        {/* Editorial Unit Rows */}
        <div className="divide-y divide-[#d3cfc8]/40">
          {BUSINESS_UNITS.map((unit) => (
            <div
              key={unit.number}
              className="group py-12 md:py-14 hover:bg-[#f4f3f1]/60 transition-all duration-300 px-2 md:px-4"
            >
              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-10 items-start">
                {/* Number & Unit Title */}
                <div className="md:col-span-3 flex items-start gap-4">
                  <span className="text-[11px] font-mono uppercase tracking-widest text-[#7b766f] group-hover:text-[#121313] transition-colors pt-1">
                    {unit.number}
                  </span>
                  <div>
                    <span className="font-serif text-[26px] md:text-[28px] text-[#191b1b] block leading-tight">
                      {unit.title}
                    </span>
                    <span className="text-[11px] uppercase tracking-[0.14em] text-[#5f5d59] font-medium block mt-1">
                      {unit.subtitle}
                    </span>
                  </div>
                </div>

                {/* Description Column */}
                <div className="md:col-span-5">
                  <h3 className="font-serif text-[22px] md:text-[24px] text-[#191b1b] mb-2 leading-snug">
                    {unit.headline}
                  </h3>
                  <p className="text-[15px] text-[#5f5d59] leading-relaxed">
                    {unit.description}
                  </p>
                </div>

                {/* Brands Column */}
                <div className="md:col-span-4 space-y-2 pt-1 md:pt-0 md:text-right">
                  <span className="text-[11px] uppercase tracking-[0.18em] text-[#7b766f] font-semibold block">
                    {unit.brands.length > 1 ? 'Marcas y productos' : 'Marca'}
                  </span>
                  <div className="text-[13px] text-[#191b1b] flex md:justify-end items-center gap-1.5 flex-wrap">
                    {unit.brands.map((brandName, idx) => (
                      <React.Fragment key={brandName}>
                        <button
                          onClick={() => onSelectBrandName(brandName)}
                          className="hover:text-black hover:underline decoration-1 underline-offset-4 cursor-pointer font-medium transition-colors"
                          title={`Ver detalles de ${brandName}`}
                        >
                          {brandName}
                        </button>
                        {idx < unit.brands.length - 1 && <span className="text-[#d3cfc8]">•</span>}
                      </React.Fragment>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
