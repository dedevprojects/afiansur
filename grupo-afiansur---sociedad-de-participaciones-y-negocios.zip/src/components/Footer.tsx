import React from 'react';

interface FooterProps {
  onOpenContact: () => void;
  onOpenTerms: () => void;
  onOpenPrivacy: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenContact, onOpenTerms, onOpenPrivacy }) => {
  return (
    <footer className="w-full bg-[#f4f3f1] border-t border-[#d3cfc8]/40">
      <div className="w-full max-w-7xl mx-auto px-6 md:px-16 py-16 md:py-20">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 md:gap-14">
          {/* Main Logo & Mission */}
          <div className="md:col-span-5 flex flex-col justify-between">
            <div className="space-y-4">
              <a href="#" className="inline-block" aria-label="Grupo Afiansur">
                <img
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuBzaqOgQFU1JIESnzq1pYekjSeQmr2G_8FViaYtbM7syaEZxsY8DORcuGuQ9o-1rcQWd_blDPh9DNPR3dXIPaXMOHV-a8NDU3-549tf7qq8GBH_MRxKiQzNefR3KzGJ0JaEEGCFe_QeAqD5pRRbTcuM7pYcurjLMKn8nDCsxpcE6Vypf-kJOtJov1MRzGQpbklCOtaa82QjkHg2wF1MdJS-0rrMT2kES8laEK-WHebn8mN8IUkwflfzH4f7xzRU2w-Y_mc"
                  alt="Grupo Afiansur"
                  className="h-10 md:h-11 w-auto object-contain mix-blend-multiply"
                />
              </a>
              <p className="text-[15px] text-[#5f5d59] max-w-md leading-relaxed mt-4">
                Un grupo empresario con negocios en tecnología, comunicación, talento, medios y educación.
              </p>
            </div>
            <div className="mt-8">
              <span className="text-[11px] uppercase tracking-widest text-[#7b766f]">
                Buenos Aires • Asunción • Madrid
              </span>
            </div>
          </div>

          {/* Institutional Index */}
          <div className="md:col-span-3 space-y-4">
            <span className="text-[11px] uppercase tracking-widest text-[#191b1b] font-semibold block">
              Índice Institucional
            </span>
            <ul className="space-y-2">
              <li className="border-b border-[#d3cfc8]/30 pb-2">
                <a href="#el-grupo" className="text-[13px] text-[#5f5d59] hover:text-[#191b1b] transition-colors">
                  El Grupo
                </a>
              </li>
              <li className="border-b border-[#d3cfc8]/30 pb-2">
                <a href="#unidades" className="text-[13px] text-[#5f5d59] hover:text-[#191b1b] transition-colors">
                  Unidades de Negocio
                </a>
              </li>
              <li className="border-b border-[#d3cfc8]/30 pb-2">
                <a href="#nuestros-negocios" className="text-[13px] text-[#5f5d59] hover:text-[#191b1b] transition-colors">
                  Nuestros Negocios
                </a>
              </li>
              <li className="border-b border-[#d3cfc8]/30 pb-2">
                <button
                  onClick={onOpenContact}
                  className="text-[13px] text-[#5f5d59] hover:text-[#191b1b] transition-colors cursor-pointer text-left"
                >
                  Contacto
                </button>
              </li>
            </ul>
          </div>

          {/* Contact Information */}
          <div className="md:col-span-4 space-y-4">
            <span className="text-[11px] uppercase tracking-widest text-[#191b1b] font-semibold block">
              Contacto
            </span>
            <div className="space-y-2 text-[13px] text-[#5f5d59]">
              <p>Ciudad Autónoma de Buenos Aires, Argentina</p>
              <p className="pt-1 font-mono text-[#191b1b] select-all">contacto@grupoafiansur.com</p>
              <p className="text-xs text-[#7b766f] pt-2">
                Horario de atención institucional: Lunes a Viernes de 09:00 a 18:00 (GMT-3)
              </p>
            </div>
          </div>
        </div>

        {/* Legal Bar */}
        <div className="mt-14 pt-6 border-t border-[#d3cfc8]/30 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-[11px] text-[#5f5d59]">
            © 2025 Grupo Afiansur S.A. Todos los derechos reservados.
          </p>
          <div className="flex items-center gap-6">
            <button
              onClick={onOpenTerms}
              className="text-[11px] text-[#5f5d59] hover:text-[#191b1b] transition-colors cursor-pointer"
            >
              Términos y Condiciones
            </button>
            <button
              onClick={onOpenPrivacy}
              className="text-[11px] text-[#5f5d59] hover:text-[#191b1b] transition-colors cursor-pointer"
            >
              Política de Privacidad
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
