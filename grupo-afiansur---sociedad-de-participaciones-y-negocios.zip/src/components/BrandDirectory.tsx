import React, { useState } from 'react';
import { ArrowUpRight, Search, X } from 'lucide-react';
import { Brand } from '../data/afiansurData';

interface BrandDirectoryProps {
  brands: Brand[];
  onSelectBrand: (brand: Brand) => void;
}

export const BrandDirectory: React.FC<BrandDirectoryProps> = ({ brands, onSelectBrand }) => {
  const [selectedFilter, setSelectedFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filterOptions = [
    { id: 'all', label: 'Todas las áreas' },
    { id: 'tecnologia', label: 'Tecnología' },
    { id: 'comunicacion', label: 'Comunicación' },
    { id: 'talento', label: 'Talento Humano' },
    { id: 'medios', label: 'Medios & Contenidos' },
    { id: 'educacion', label: 'Educación' },
  ];

  const filteredBrands = brands.filter((brand) => {
    const matchesFilter = selectedFilter === 'all' || brand.category === selectedFilter;
    const matchesSearch =
      brand.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      brand.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      brand.categoryLabel.toLowerCase().includes(searchQuery.toLowerCase()) ||
      brand.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesFilter && matchesSearch;
  });

  // Grouped brands for the default monograph layout
  const techBrands = brands.filter((b) => b.category === 'tecnologia');
  const commBrands = brands.filter((b) => b.category === 'comunicacion');
  const talentBrands = brands.filter((b) => b.category === 'talento');
  const mediaBrands = brands.filter((b) => b.category === 'medios');
  const eduBrands = brands.filter((b) => b.category === 'educacion');

  const isFilteredOrSearched = selectedFilter !== 'all' || searchQuery.trim().length > 0;

  return (
    <section className="w-full px-6 md:px-16 py-20 md:py-24 bg-[#f9f9f8] border-b border-[#d3cfc8]/40" id="nuestros-negocios">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-14 items-baseline pb-10 border-b border-[#d3cfc8]/40">
          <div className="md:col-span-5">
            <span className="text-[11px] uppercase tracking-[0.2em] font-semibold text-[#5f5d59] block mb-2">
              NUESTROS NEGOCIOS
            </span>
            <h2 className="font-serif text-[38px] md:text-[52px] text-[#191b1b] tracking-tight leading-tight">
              Cada negocio, su identidad.
            </h2>
          </div>
          <div className="md:col-span-7">
            <p className="text-[16px] md:text-[17px] text-[#5f5d59] leading-relaxed">
              Las marcas que integran Grupo Afiansur operan con propuestas y especialidades propias. El grupo les brinda un marco común para desarrollar sus actividades y explorar nuevas oportunidades con autonomía de gestión y sinergia corporativa.
            </p>
          </div>
        </div>

        {/* Filter & Search Bar */}
        <div className="mt-8 mb-12 flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[#d3cfc8]/30">
          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 md:pb-0 scrollbar-none">
            {filterOptions.map((opt) => (
              <button
                key={opt.id}
                onClick={() => setSelectedFilter(opt.id)}
                className={`text-[11px] uppercase tracking-[0.16em] px-3.5 py-1.5 transition-all whitespace-nowrap cursor-pointer ${
                  selectedFilter === opt.id
                    ? 'bg-[#121313] text-white font-semibold'
                    : 'text-[#5f5d59] hover:text-[#191b1b] hover:bg-[#edebe7]'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>

          {/* Search Input */}
          <div className="relative min-w-[240px]">
            <Search className="w-3.5 h-3.5 text-[#7b766f] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Buscar marcas o capacidades..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#f4f3f1] border border-[#d3cfc8]/70 pl-8 pr-8 py-1.5 text-xs text-[#191b1b] placeholder:text-[#7b766f] focus:outline-hidden focus:border-[#121313]"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#7b766f] hover:text-[#191b1b]"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* If user filtered or searched, show direct results grid */}
        {isFilteredOrSearched ? (
          <div>
            <div className="mb-4 text-xs text-[#5f5d59] uppercase tracking-wider flex items-center justify-between">
              <span>{filteredBrands.length} resultados encontrados</span>
              <button
                onClick={() => {
                  setSelectedFilter('all');
                  setSearchQuery('');
                }}
                className="hover:underline text-[#191b1b]"
              >
                Restablecer vista editorial
              </button>
            </div>

            {filteredBrands.length === 0 ? (
              <div className="py-16 text-center border border-dashed border-[#d3cfc8]/70 p-8">
                <p className="font-serif text-xl text-[#191b1b] mb-2">No se encontraron marcas</p>
                <p className="text-sm text-[#5f5d59]">Intente con otros términos o seleccione otra área temática.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {filteredBrands.map((brand) => (
                  <div
                    key={brand.id}
                    className="p-5 bg-[#f4f3f1] hover:bg-[#edebe7] transition-all duration-200 group border border-[#d3cfc8]/50 hover:border-[#191b1b]/40 flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex justify-between items-start mb-3">
                        <span className="text-[10px] tracking-widest uppercase text-[#5f5d59] font-medium">
                          {brand.categoryLabel}
                        </span>
                        <a
                          href={brand.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-[#7b766f] hover:text-[#191b1b] transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                          title="Visitar sitio oficial"
                        >
                          <ArrowUpRight className="w-4 h-4" />
                        </a>
                      </div>

                      <button
                        onClick={() => onSelectBrand(brand)}
                        className="font-serif text-[22px] text-[#191b1b] text-left group-hover:underline decoration-1 underline-offset-4 cursor-pointer block mb-2"
                      >
                        {brand.name}
                      </button>
                      <p className="text-[13px] text-[#5f5d59] leading-relaxed mb-4">
                        {brand.summary}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-[#d3cfc8]/30 flex items-center justify-between text-[11px]">
                      <button
                        onClick={() => onSelectBrand(brand)}
                        className="text-[#191b1b] hover:text-black font-semibold uppercase tracking-wider underline decoration-dotted"
                      >
                        Ver Ficha
                      </button>
                      <span className="font-mono text-[#7b766f]">{brand.founded}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          /* Default Monograph Grouped Brand Ledger Table matching the reference HTML */
          <div className="space-y-16">
            {/* Group 1: Tecnología y Digital */}
            <div>
              <div className="flex items-center justify-between pb-2 border-b border-[#d3cfc8]/50 mb-5">
                <span className="text-[11px] uppercase tracking-[0.2em] font-semibold text-[#191b1b]">
                  Área • Tecnología y Software
                </span>
                <span className="text-[11px] font-mono text-[#7b766f]">04 Unidades</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                {techBrands.map((brand) => {
                  const roleLabel =
                    brand.id === 'agencia-gol' ? 'Desarrollo' :
                    brand.id === 'agroconexiones' ? 'Agroindustria' :
                    brand.id === 'reservaclick' ? 'Servicios' : 'Inmobiliario';

                  return (
                    <div
                      key={brand.id}
                      onClick={() => onSelectBrand(brand)}
                      className="p-5 bg-[#f4f3f1] hover:bg-[#edebe7] transition-all duration-200 group border border-[#d3cfc8]/50 hover:border-[#191b1b]/40 cursor-pointer flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex justify-between items-start mb-3">
                          <span className="text-[10px] tracking-widest uppercase text-[#5f5d59] font-medium">
                            {roleLabel}
                          </span>
                          <a
                            href={brand.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            onClick={(e) => e.stopPropagation()}
                            className="text-[#7b766f] hover:text-[#191b1b] transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                            title="Visitar sitio"
                          >
                            <ArrowUpRight className="w-4 h-4" />
                          </a>
                        </div>
                        <div className="font-serif text-[22px] text-[#191b1b] group-hover:underline decoration-1 underline-offset-4">
                          {brand.name}
                        </div>
                        <p className="text-[13px] text-[#5f5d59] mt-2 leading-relaxed">
                          {brand.summary}
                        </p>
                      </div>

                      <div className="mt-4 pt-2 border-t border-[#d3cfc8]/20 flex items-center justify-between text-[11px] text-[#7b766f]">
                        <span className="uppercase tracking-wider">Dossier</span>
                        <span className="font-mono">{brand.headquarters.split('·')[0]}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Group 2: Comunicación y Creatividad */}
            <div>
              <div className="flex items-center justify-between pb-2 border-b border-[#d3cfc8]/50 mb-5">
                <span className="text-[11px] uppercase tracking-[0.2em] font-semibold text-[#191b1b]">
                  Área • Comunicación y Producción Audiovisual
                </span>
                <span className="text-[11px] font-mono text-[#7b766f]">03 Unidades</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {commBrands.map((brand) => {
                  const roleLabel =
                    brand.id === 'krafyx' ? 'Diseño e Identidad' :
                    brand.id === 'hatrixa' ? 'Publicidad' : 'Audiovisual';

                  return (
                    <div
                      key={brand.id}
                      onClick={() => onSelectBrand(brand)}
                      className="p-5 bg-[#f4f3f1] hover:bg-[#edebe7] transition-all duration-200 group border border-[#d3cfc8]/50 hover:border-[#191b1b]/40 cursor-pointer flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex justify-between items-start mb-3">
                          <span className="text-[10px] tracking-widest uppercase text-[#5f5d59] font-medium">
                            {roleLabel}
                          </span>
                          <a
                            href={brand.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            onClick={(e) => e.stopPropagation()}
                            className="text-[#7b766f] hover:text-[#191b1b] transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                            title="Visitar sitio"
                          >
                            <ArrowUpRight className="w-4 h-4" />
                          </a>
                        </div>
                        <div className="font-serif text-[22px] text-[#191b1b] group-hover:underline decoration-1 underline-offset-4">
                          {brand.name}
                        </div>
                        <p className="text-[13px] text-[#5f5d59] mt-2 leading-relaxed">
                          {brand.summary}
                        </p>
                      </div>

                      <div className="mt-4 pt-2 border-t border-[#d3cfc8]/20 flex items-center justify-between text-[11px] text-[#7b766f]">
                        <span className="uppercase tracking-wider">Dossier</span>
                        <span className="font-mono">{brand.headquarters.split('·')[0]}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Group 3, 4 & 5: Talento, Medios, Educación */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-10 md:gap-12">
              {/* Talento */}
              <div className="space-y-4">
                <div className="pb-2 border-b border-[#d3cfc8]/50 flex items-center justify-between">
                  <span className="text-[11px] uppercase tracking-[0.2em] font-semibold text-[#191b1b]">
                    Área • Talento Humano
                  </span>
                </div>
                <div className="space-y-4">
                  {talentBrands.map((brand) => (
                    <div
                      key={brand.id}
                      onClick={() => onSelectBrand(brand)}
                      className="p-5 bg-[#f4f3f1] hover:bg-[#edebe7] transition-all duration-200 group border border-[#d3cfc8]/50 hover:border-[#191b1b]/40 cursor-pointer"
                    >
                      <div className="flex justify-between items-start">
                        <span className="font-serif text-[22px] text-[#191b1b] group-hover:underline decoration-1 underline-offset-4">
                          {brand.name}
                        </span>
                        <a
                          href={brand.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="text-[#7b766f] hover:text-[#191b1b] transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                        >
                          <ArrowUpRight className="w-4 h-4" />
                        </a>
                      </div>
                      <p className="text-[13px] text-[#5f5d59] mt-2 leading-relaxed">
                        {brand.summary}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Medios */}
              <div className="space-y-4">
                <div className="pb-2 border-b border-[#d3cfc8]/50 flex items-center justify-between">
                  <span className="text-[11px] uppercase tracking-[0.2em] font-semibold text-[#191b1b]">
                    Área • Medios y Editorial
                  </span>
                </div>
                <div className="space-y-4">
                  {mediaBrands.map((brand) => (
                    <div
                      key={brand.id}
                      onClick={() => onSelectBrand(brand)}
                      className="p-5 bg-[#f4f3f1] hover:bg-[#edebe7] transition-all duration-200 group border border-[#d3cfc8]/50 hover:border-[#191b1b]/40 cursor-pointer"
                    >
                      <div className="flex justify-between items-start">
                        <span className="font-serif text-[22px] text-[#191b1b] group-hover:underline decoration-1 underline-offset-4">
                          {brand.name}
                        </span>
                        <a
                          href={brand.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="text-[#7b766f] hover:text-[#191b1b] transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                        >
                          <ArrowUpRight className="w-4 h-4" />
                        </a>
                      </div>
                      <p className="text-[13px] text-[#5f5d59] mt-2 leading-relaxed">
                        {brand.summary}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Educación & Incubación */}
              <div className="space-y-4">
                <div className="pb-2 border-b border-[#d3cfc8]/50 flex items-center justify-between">
                  <span className="text-[11px] uppercase tracking-[0.2em] font-semibold text-[#191b1b]">
                    Área • Formación Continua
                  </span>
                </div>
                <div className="space-y-4">
                  {eduBrands.map((brand) => (
                    <div
                      key={brand.id}
                      onClick={() => onSelectBrand(brand)}
                      className="p-5 bg-[#f4f3f1] hover:bg-[#edebe7] transition-all duration-200 group border border-[#d3cfc8]/50 hover:border-[#191b1b]/40 cursor-pointer"
                    >
                      <div className="flex justify-between items-start">
                        <span className="font-serif text-[22px] text-[#191b1b] group-hover:underline decoration-1 underline-offset-4">
                          {brand.name}
                        </span>
                        <a
                          href={brand.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="text-[#7b766f] hover:text-[#191b1b] transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                        >
                          <ArrowUpRight className="w-4 h-4" />
                        </a>
                      </div>
                      <p className="text-[13px] text-[#5f5d59] mt-2 leading-relaxed">
                        {brand.summary}
                      </p>
                    </div>
                  ))}

                  {/* Incubation card matching screenshot */}
                  <div className="p-5 bg-white/70 border border-dashed border-[#d3cfc8] flex items-center justify-between">
                    <span className="text-[11px] uppercase tracking-wider text-[#5f5d59] font-medium">
                      Nuevas iniciativas en incubación
                    </span>
                    <span className="w-1.5 h-1.5 rounded-full bg-[#7b766f]"></span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
